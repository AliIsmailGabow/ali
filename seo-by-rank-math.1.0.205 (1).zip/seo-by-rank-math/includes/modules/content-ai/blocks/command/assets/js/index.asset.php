<?php
return [
	'dependencies' => [
		'wp-element',
		'wp-block-editor',
	],
	'version'      => rank_math()->version,
];
