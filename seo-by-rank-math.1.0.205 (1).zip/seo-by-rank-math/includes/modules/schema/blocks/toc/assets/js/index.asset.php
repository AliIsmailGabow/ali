<?php
return [
	'dependencies' => [
		'wp-blocks',
		'wp-element',
		'wp-components',
		'wp-block-editor',
		'wp-data',
		'wp-dom',
		'wp-url',
		'wp-i18n',
		'lodash',
		'wp-primitives',
		'wp-reusable-blocks',
	],
	'version'      => rank_math()->version,
];
